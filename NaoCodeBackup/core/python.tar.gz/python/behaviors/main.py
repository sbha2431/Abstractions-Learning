"""Blank behavior."""

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

from task import Task


class Playing(Task):
    """Main behavior task."""

    pass
