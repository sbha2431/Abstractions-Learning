#ifndef IMAGEPROCESSOR_H
#define IMAGEPROCESSOR_H

#include <kinematics/ForwardKinematics.h>
#include <common/RobotDimensions.h>
#include <common/Profiling.h>
#include <memory/TextLogger.h>
#include <vision/CameraMatrix.h>
#include <vision/VisionBlocks.h>
#include <common/RobotInfo.h>
#include <common/RobotCalibration.h>
#include <vision/structures/BallCandidate.h>
#include <math/Pose3D.h>
#include <vision/structures/VisionParams.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
class BallDetector;
class Classifier;
class BeaconDetector;

// The Runregion data structure definition.


// class ImageProcessor::BlobClass {
//   int x_cord=0;
//   int y_cord=0;
// }
/// @ingroup vision
class ImageProcessor {
  public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW  
    ImageProcessor(VisionBlocks& vblocks, const ImageParams& iparams, Camera::Type camera);
    ~ImageProcessor();
    void processFrame();
    void init(TextLogger*);
    void SetColorTable(unsigned char*);
    std::unique_ptr<BeaconDetector> beacon_detector_;
    std::unique_ptr<Classifier> color_segmenter_;
    unsigned char* getImg();
    unsigned char* getSegImg();
    unsigned char* getColorTable();
    bool isRawImageLoaded();
    int getImageHeight();
    int getImageWidth();
    const ImageParams& getImageParams() const { return iparams_; }
    const CameraMatrix& getCameraMatrix();
    void setCalibration(const RobotCalibration& calibration);
    void enableCalibration(bool value);
    void updateTransform();
    std::vector<BallCandidate*> getBallCandidates();
    BallCandidate* getBestBallCandidate();
    bool isImageLoaded();
    void detectBall();
    void detectGoal();
    bool findBall(int& imageX, int& imageY);
    bool findGoal(int& imageX, int& imageY);
    void RLE();
    struct RunRegion {
    int color;    //color associated with the run region.
    RunRegion  *root;   //the root node of the runregion.
    RunRegion *listNext; //pointer to the next runregion in the current run length
    RunRegion *nextRun;
    int  xLoc;   //x location of the root node.
    int  yLoc;   //y location of the root node.
    int  runLength;   // number of run lengths with this region.
    int  boundingBox;   //the bounding box that this region belongs to.
    typedef RunRegion* RegPtr;
    RunRegion(int color, int xLoc,int yLoc, int num){
        printf("constructing runColor: %d\n",color);
        color = color;
        xLoc = xLoc;
        yLoc = yLoc;
        runLength = num;
        listNext = nextRun = NULL;
    }
  };
    
  // The BoundingBox data structure definition
  struct BoundingBox {
    BoundingBox* prevBox; //pointer to the previous bounding box.
    BoundingBox* nextBox; // pointer to the next bounding box.
    int ULx; //upper left corner x coordinate.
    int ULy; //upper left corner y coordinate.
    int  LRx;  
    int  LRy;
    bool  lastBox;
    int numRunLengths; //number of runlengths associated with this bounding box.
    int numPixels; //number of pixels in this bounding box
    int rrcount;
    int color; //color cooresponding to this bounding box
    std::list<RunRegion*> listRR;
    //RunRegion*  eoList;
    float prob; //probability corresponding to this bounding box
    BoundingBox(int ULx,int ULy,int LRx, int LRy,int numRunLengths,int numPixels,int color, RunRegion* RunPtr){
        printf("constructing boxColor: %d\n",color);
        color = color;
        ULx = ULx; //upper left corner x coordinate.
        ULy = ULy; //upper left corner y coordinate.
        LRx = LRx;  
        LRy = LRy;
        numRunLengths = numRunLengths; //number of runlengths associated with this bounding box.
        numPixels = numPixels; //number of pixels in this bounding box
        nextBox = NULL;
        std::cout << RunPtr << "\n";
        listRR.push_back(RunPtr);
    }
    ~BoundingBox(){ //
        if(nextBox){nextBox->prevBox = prevBox;}      
        else{nextBox = NULL;}
        if(prevBox){prevBox->nextBox = nextBox;}
        else{prevBox = NULL;}
    }
  };
  typedef BoundingBox* BoxPtr;
  typedef RunRegion* RegPtr;
  ///*
  BoundingBox* findBB(BoundingBox* head,RegPtr regptr);
  RunRegion* findRR(RunRegion* head,int x,int y);
  void mergeBB(BoundingBox* box_a,BoundingBox* box_b,BoxPtr& headBox);
  void RunRegion_head_insert(RegPtr& headRun, int color, int xLoc,int yLoc, int num);
  void BoundingBox_head_insert(BoxPtr& headBox,int ULx,int ULy,int LRx, int LRy,int numRunLengths,int numPixels,int color, RegPtr& RunPtr);
  void BoundingBox_prev_compile(BoundingBox* head) ;
  void unionBB(BoundingBox* boxhead[],RunRegion* runhead,unsigned char* image,int k_width);
  void display(RunRegion* head);
  void displayBox(BoundingBox* head); //*/
  // int mergeBoundingBox();

  private:
    int getTeamColor();
    double getCurrentTime();

    VisionBlocks& vblocks_;
    const ImageParams& iparams_;
    Camera::Type camera_;
    CameraMatrix cmatrix_;
    
    VisionParams vparams_;
    unsigned char* color_table_;
    TextLogger* textlogger;

    float getHeadPan() const;
    float getHeadTilt() const;
    float getHeadChange() const;
    
    std::unique_ptr<RobotCalibration> calibration_;
    bool enableCalibration_;

    //void saveImg(std::string filepath);
    int topFrameCounter_ = 0;
    int bottomFrameCounter_ = 0;
};

#endif
