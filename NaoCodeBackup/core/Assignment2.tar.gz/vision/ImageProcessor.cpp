#include <vision/ImageProcessor.h>
#include <vision/Classifier.h>
#include <vision/BeaconDetector.h>
#include <vision/Logging.h>
#include <iostream>
#include <tuple>

#define PIX_STEP  1
#define PIX_OVERLAP  0
#define COLOR_NUM 9
#define MIN_RUNLENGTH 0

ImageProcessor::ImageProcessor(VisionBlocks& vblocks, const ImageParams& iparams, Camera::Type camera) :
  vblocks_(vblocks), iparams_(iparams), camera_(camera), cmatrix_(iparams_, camera)
{
  enableCalibration_ = false;
  color_segmenter_ = std::make_unique<Classifier>(vblocks_, vparams_, iparams_, camera_);
  beacon_detector_ = std::make_unique<BeaconDetector>(DETECTOR_PASS_ARGS);
  calibration_ = std::make_unique<RobotCalibration>();

}

ImageProcessor::~ImageProcessor() {
}

void ImageProcessor::init(TextLogger* tl){
  textlogger = tl;
  vparams_.init();
  color_segmenter_->init(tl);
  beacon_detector_->init(tl);
}

unsigned char* ImageProcessor::getImg() {
  if(camera_ == Camera::TOP)
    return vblocks_.image->getImgTop();
  return vblocks_.image->getImgBottom();

}

//void ImageProcessor::saveImg(std::string filepath) {
//  cv::Mat mat;
//  int xstep_ = 1 << iparams_.defaultHorizontalStepScale;
//  int ystep_ = 1 << iparams_.defaultVerticalStepScale;
//  cv::resize(color_segmenter_->img_grayscale(), mat, cv::Size(), 1.0 / xstep_, 1.0 / ystep_, cv::INTER_NEAREST); 
  
//  cv::imwrite(filepath, mat);
//}

unsigned char* ImageProcessor::getSegImg(){
  if(camera_ == Camera::TOP)
    return vblocks_.robot_vision->getSegImgTop();
  return vblocks_.robot_vision->getSegImgBottom();
}

unsigned char* ImageProcessor::getColorTable(){
  return color_table_;
}

const CameraMatrix& ImageProcessor::getCameraMatrix(){
  return cmatrix_;
}

void ImageProcessor::updateTransform(){
  BodyPart::Part camera;
  if(camera_ == Camera::TOP)
    camera = BodyPart::top_camera;
  else
    camera = BodyPart::bottom_camera;

  Pose3D pcamera;
  if(enableCalibration_) {
    float joints[NUM_JOINTS], sensors[NUM_SENSORS], dimensions[RobotDimensions::NUM_DIMENSIONS];
    memcpy(joints, vblocks_.joint->values_.data(), NUM_JOINTS * sizeof(float));
    memcpy(sensors, vblocks_.sensor->values_.data(), NUM_SENSORS * sizeof(float));
    memcpy(dimensions, vblocks_.robot_info->dimensions_.values_, RobotDimensions::NUM_DIMENSIONS * sizeof(float));
    Pose3D *rel_parts = vblocks_.body_model->rel_parts_.data(), *abs_parts = vblocks_.body_model->abs_parts_.data();
    calibration_->applyJoints(joints);
    calibration_->applySensors(sensors);
    calibration_->applyDimensions(dimensions);
    ForwardKinematics::calculateRelativePose(joints, rel_parts, dimensions);
#ifdef TOOL
    Pose3D base = ForwardKinematics::calculateVirtualBase(calibration_->useLeft, rel_parts);
    ForwardKinematics::calculateAbsolutePose(base, rel_parts, abs_parts);
#else
    ForwardKinematics::calculateAbsolutePose(sensors, rel_parts, abs_parts);
#endif
    cmatrix_.setCalibration(*calibration_);
    pcamera = abs_parts[camera];
  }
  else pcamera = vblocks_.body_model->abs_parts_[camera];

  if(vblocks_.robot_state->WO_SELF == WO_TEAM_COACH) {
    auto self = vblocks_.world_object->objects_[vblocks_.robot_state->WO_SELF];
    pcamera.translation.z += self.height;
  }

  cmatrix_.updateCameraPose(pcamera);
}

bool ImageProcessor::isRawImageLoaded() {
  if(camera_ == Camera::TOP)
    return vblocks_.image->isLoaded();
  return vblocks_.image->isLoaded();
}

int ImageProcessor::getImageHeight() {
  return iparams_.height;
}

int ImageProcessor::getImageWidth() {
  return iparams_.width;
}

double ImageProcessor::getCurrentTime() {
  return vblocks_.frame_info->seconds_since_start;
}

void ImageProcessor::setCalibration(const RobotCalibration& calibration){
  *calibration_ = calibration;
}

void ImageProcessor::processFrame(){
  if(camera_ == Camera::BOTTOM) return;
  tlog(30, "Process Frame camera %i", camera_);
  // Horizon calculation
  tlog(30, "Calculating horizon line");
  updateTransform();
  HorizonLine horizon = HorizonLine::generate(iparams_, cmatrix_, 20000);
  vblocks_.robot_vision->horizon = horizon;
  tlog(30, "Classifying Image: %i", camera_);
  if(!color_segmenter_->classifyImage(color_table_)) return;

  RLE();
}

void ImageProcessor::detectBall() {
  int imageX, imageY;
 
// function defined elsewhere that fills in imageX, imageY by reference
  if(!findBall(imageX, imageY)) return;
  //
  WorldObject* ball = &vblocks_.world_object->objects_[WO_BALL];
  ball->imageCenterX = imageX;
  ball->imageCenterY = imageY;

  Position p = cmatrix_.getWorldPosition(imageX, imageY);
  std:cout << imageX << " " << imageY;
  ball->visionBearing = cmatrix_.bearing(p);
  ball->visionElevation = cmatrix_.elevation(p);
  ball->visionDistance = cmatrix_.groundDistance(p);


  ball->seen = true;return;
}

void ImageProcessor::detectGoal() {
  int imageX, imageY;
 
// function defined elsewhere that fills in imageX, imageY by reference
  if(!findGoal(imageX, imageY)) return;
  //
  WorldObject* goal = &vblocks_.world_object->objects_[WO_OWN_GOAL];
  goal->imageCenterX = imageX;
  goal->imageCenterY = imageY;

  Position p = cmatrix_.getWorldPosition(imageX, imageY);
  goal->visionBearing = cmatrix_.bearing(p);
  goal->visionElevation = cmatrix_.elevation(p);
  goal->visionDistance = cmatrix_.groundDistance(p);


  goal->seen = true;return;
}

bool ImageProcessor::findBall(int& imageX, int& imageY) {
  //if (camera_ == Camera::BOTTOM) { return false; }
  auto total=0;
  auto xpixsum=0.0;
  auto ypixsum=0.0;
  int kheight = iparams_.height;
  int kwidth = iparams_.width;
  // Process from left to right
  for(int x = 0; x < kwidth; x+=PIX_STEP) {
    // Process from top to bottom
      for(int y = 0; y < kheight; y+=PIX_STEP) {
      // Retrieve the segmented color of the pixel at (x,y)
        auto c = getSegImg()[y * kwidth + x];
        if(c == c_ORANGE){ 
          total++;
          xpixsum+=x;
          ypixsum+=y;}
    }
  }
  
  float xpixmean=0.0;
  float ypixmean=0.0;
  if (total>200/PIX_STEP/PIX_STEP){
  imageX=float(xpixsum)/float(total);
  imageY=float(ypixsum)/float(total);
  return true;}
  return false;
}


bool ImageProcessor::findGoal(int& imageX, int& imageY) {
  //if (camera_ == Camera::BOTTOM) { return false; }
  auto total=0;
  auto xpixsum=0.0;
  auto ypixsum=0.0;
  int kheight = iparams_.height;
  int kwidth = iparams_.width;
  int step = iparams_.width / 320;
  // Process from left to right
  for(int x = 0; x < kwidth; x+=PIX_STEP) {
    // Process from top to bottom
      for(int y = 0; y < kheight; y+=PIX_STEP) {
      // Retrieve the segmented color of the pixel at (x,y)
        auto c = getSegImg()[y * kwidth + x];
        if(c == c_BLUE){ 
          total++;
          xpixsum+=x;
          ypixsum+=y;}
    }
  }
  
  float xpixmean=0.0;
  float ypixmean=0.0;
  if (total>200){
  imageX=float(xpixsum)/float(total);
  imageY=float(ypixsum)/float(total);
  return true;}
  return false;
}


void ImageProcessor::RLE(){
  std::cout << "So it begins... \n";
  int k_height = iparams_.height;
  int k_width = iparams_.width;
  // Get colors for whole image
  unsigned char* image = getSegImg();
  std::vector<int> allcolors = {c_ORANGE,c_PINK,c_BLUE,c_YELLOW,c_WHITE};
  // Sweep through image to find Run Line Encoding of colors to get first color blobs
  RegPtr headRun;
  BoxPtr headBox[COLOR_NUM];
  headRun = NULL;
  int num=1;
  int c_offset = 0;
  int colorprev;
  int color;
  // std::map<int,RegPtr>HeadRunRow
  for(int c : {0,1,2,3,4,5,6,7,8,9}){headBox[c]=NULL;} // Define heads of each colorbox run

  for(int y = 0; y < k_height; y+=PIX_STEP){
    num = 1;
    c_offset = 0;
    for(int x=PIX_STEP; x < k_width; x+= PIX_STEP){
      color = image[y*k_width+x];
      
      bool flag = false;
      if(std::count(allcolors.begin(),allcolors.end(),color) || flag){
      	  flag = true;
      	  // std::cout << "Color index " << y*k_width+x <<"\n";
      	  // std::cout << "Prev Color index " << y*k_width+x-PIX_STEP <<"\n";
	      colorprev = image[y*k_width+x-PIX_STEP];
	      // std::cout << "Color " << color << " prevcolor beore if" << colorprev <<"\n";
	      if(std::count(allcolors.begin(),allcolors.end(),colorprev)){
		      // std::cout << "Color " << color << " prevcolor " << colorprev <<"\n";
		      if((color!=colorprev)||(x==k_width-PIX_STEP)){
		      	flag = false;
		        std::cout << "New Run length " << "Color " << color << " prevcolor " << colorprev << " Length " << num <<  " xLoc " << x-num+c_offset <<  " yLoc " << y  << "\n";
		        if(x==k_width-PIX_STEP){num+=PIX_STEP;c_offset=PIX_STEP;}
		        
		        if(num>MIN_RUNLENGTH && std::count(allcolors.begin(),allcolors.end(),color)){
		          if (!headRun){
		          	std::cout << "Creating new runregion\n " ;
		            headRun = new RunRegion(colorprev,x-num+c_offset,y,num);
		            headBox[colorprev] = new BoundingBox(x-num+c_offset,y,x,y,1,num,colorprev,headRun);
		            num = 1;
		          }
		          else{
		          	std::cout << "Inserting new runregion\n " ;
		            RunRegion_head_insert(headRun, colorprev,x-num+c_offset,y,num);
		            if(!headBox[colorprev]){ printf("making new BoundingBox\n");  headBox[colorprev] = new BoundingBox(x-num+c_offset,y,x,y,1,num,colorprev,headRun);}
		            else{printf("add to old BoundingBox\n");BoundingBox_head_insert(headBox[colorprev], x-num+c_offset,y,x,y,1,num,colorprev,headRun);}
		            num = 1;
		          }
		        }
		        else{
		            num = 1;
		        }
		      }
		      else{num+=PIX_STEP;}
		    }
	      else{
	             num+=PIX_STEP;
	      }
      }
    }
  }
  unionBB(headBox,headRun,image,k_width);
  if(headBox[3]){displayBox(headBox[3]);}
  std::cout << "Done ... \n";
  return;
} 

int ImageProcessor::getTeamColor() {
  return vblocks_.robot_state->team_;
}

void ImageProcessor::SetColorTable(unsigned char* table) {
  color_table_ = table;
}

float ImageProcessor::getHeadChange() const {
  if (vblocks_.joint == NULL)
    return 0;
  return vblocks_.joint->getJointDelta(HeadPan);
}

std::vector<BallCandidate*> ImageProcessor::getBallCandidates() {
  return std::vector<BallCandidate*>();
}

BallCandidate* ImageProcessor::getBestBallCandidate() {
  return NULL;
}

void ImageProcessor::enableCalibration(bool value) {
  enableCalibration_ = value;
}

bool ImageProcessor::isImageLoaded() {
  return vblocks_.image->isLoaded();
}



// ImageProcessor::RunRegion* ImageProcessor::newRun(int color,int xLoc,int yLoc, int num){
//         RunRegion* tempPtr;
//         tempPtr = new RunRegion;
//         tempPtr->color = color;
//         tempPtr->xLoc = xLoc;
//         tempPtr->yLoc = yLoc;
//         tempPtr->runLength = num;
//         tempPtr->listNext = tempPtr->nextRun = NULL;
//         return tempPtr;
// }

// ImageProcessor::BoundingBox* ImageProcessor::newBox(int ULx,int ULy,int LRx, int LRy,int numRunLengths,int numPixels,RegPtr& RunPtr){
//         BoundingBox* tempPtr;
//         tempPtr = new BoundingBox;
//         tempPtr->color = RunPtr->color;
//         tempPtr->ULx = ULx; //upper left corner x coordinate.
//         tempPtr->ULy = ULy; //upper left corner y coordinate.
//         tempPtr->LRx = LRx;  
//         tempPtr->LRy = LRy;
//         tempPtr->numRunLengths = numRunLengths; //number of runlengths associated with this bounding box.
//         tempPtr->numPixels = numPixels; //number of pixels in this bounding box
//         tempPtr->nextBox = NULL;
//         tempPtr-> listRR.push_back(RunPtr);
//     return tempPtr;
// }

void ImageProcessor::RunRegion_head_insert(ImageProcessor::RegPtr& headRun, int color, int xLoc,int yLoc, int num)
{
    RegPtr temp_ptr;
    temp_ptr = new RunRegion(color,xLoc,yLoc,num);
    headRun = temp_ptr;
    ImageProcessor::RunRegion* iter;
    for (iter = headRun; iter != NULL; iter = iter->listNext){
        if (iter->color == temp_ptr -> color && iter!= headRun){
            //std::cout << iter->color << " " << temp_ptr -> color << "\n";
            //std::cout << iter << " " << temp_ptr << "\n";
            temp_ptr->nextRun = iter;
            break;
        }
             
    };
}

void ImageProcessor::BoundingBox_head_insert(ImageProcessor::BoxPtr& headBox,int ULx,int ULy,int LRx, int LRy,int numRunLengths,int numPixels,int color,ImageProcessor::RegPtr& RunPtr)
{
    BoxPtr temp_ptr;
    temp_ptr = new BoundingBox(ULx,ULy,LRx,LRy,numRunLengths,numPixels,color,RunPtr);
    headBox = temp_ptr;
}

void ImageProcessor::BoundingBox_prev_compile(ImageProcessor::BoundingBox* head) 
{ 
    BoundingBox* iter;
    BoundingBox* prev;
    for (iter = head; iter != NULL; iter = iter->nextBox){
        if (iter!=head){
            iter->prevBox = prev;
        }
        prev = iter;
    }
    // loop until the down pointer is not NULL 
     
} 


void ImageProcessor::unionBB(BoundingBox* boxhead[],RunRegion* runhead,unsigned char* image,int k_width){
    RunRegion* iter;
    // unsigned char* image2 = getSegImg();
   //  for (int y=0;y<320;y++){
    //   std::cout<<"\n";
   //  for (int x=0;x<240;x+=8){
     //  int cs = int(image[y*k_width+x]);
     //  /std::cout <<  cs << "";
    // }
    // }
    int colorup;

    for (iter = runhead; iter != NULL; iter = iter->listNext){
            if (iter->yLoc >0){              
               for(int x=iter->xLoc; x < (iter->xLoc + iter->runLength);x+=PIX_STEP){ //Scan left-right through each pixel of runlength and look up
                   colorup = image[(iter->yLoc-PIX_STEP)*k_width+x];
                   std::cout << "Searching for color " << iter-> color <<" Found color " << colorup << " \n";
                   if (iter->color == colorup ){ //If color matches then merge corresponding bounding boxes.
                       std::cout << "Found \n";
                       if (findRR(iter,x,iter->yLoc-PIX_STEP)!=iter){
                          std::cout << " Merigng \n";

                           mergeBB(findBB(boxhead[iter->color],iter),findBB(boxhead[iter->color],findRR(iter,x,iter->yLoc-PIX_STEP)),boxhead[iter->color]);
                       }
                       break;
                   }
                   }
               }
           }
}



ImageProcessor::BoundingBox* ImageProcessor::findBB(BoundingBox* head,RegPtr regptr){
    BoundingBox* iter;
    for (iter = head;iter != NULL; iter = iter->nextBox){
        if (std::find(iter->listRR.begin(), iter->listRR.end(), regptr) !=iter->listRR.end()){
            return iter;
        }
    }
    return iter;
}
                           
ImageProcessor::RunRegion* ImageProcessor::findRR(RunRegion* head,int x,int y){
    RunRegion* iter;
    for (iter=head;iter!=NULL;iter=iter-> listNext){
            if((y == iter->yLoc) && (x >= std::max(iter->xLoc,iter->xLoc) ) && (x <= (iter->xLoc+iter->runLength+PIX_OVERLAP))&&(iter->color==head->color)){
                return iter;
                }
    }
    return head;
}


void ImageProcessor::mergeBB(ImageProcessor::BoundingBox* box_a,ImageProcessor::BoundingBox* box_b,ImageProcessor::BoxPtr& headBox){
        // Find larger box
    box_a->ULx = std::min(box_a->ULx,box_b->ULx); //combined top left corner
    box_a->ULy = std::max(box_a->ULy,box_b->ULy); //combined top left corner
    box_a->LRx = std::max(box_a->LRx,box_b->LRx); //combined bottom right corner
    box_a->LRy = std::min(box_a->LRy,box_a->LRy); //combined bottom right corner
    box_a->numRunLengths += box_b->numRunLengths; 
    box_a->numPixels+= box_b->numPixels; //add pixels together
    box_a->listRR.merge(box_b->listRR); // merge runregion pointers
    //std::cout << "Merged \n ";
    if (box_b == headBox){
        //std::cout << "Merging headbox \n ";
        headBox = box_a;
    }
    //delete box_b; //delete box B
}


void ImageProcessor::display(RunRegion* head) 
{ 
    RunRegion* iter;
    for (iter = head; iter != NULL; iter = iter->listNext){
        //if (iter==head){std::cout << "yloc " << iter->yLoc << " \n";}
        std::cout << "Run region " << iter << ". "; 
        std::cout << "Colour for run region is " << iter->color << ". ";
        std::cout << "xLoc: " << iter->xLoc << " yLoc: " << iter->yLoc << ". ";
        std::cout << "Length of run region is " << iter->runLength << ". ";
        std::cout << " Next same colour run region at " << iter->nextRun << "\n";
    }; 
    // loop until the down pointer is not NULL 
}

void ImageProcessor::displayBox(ImageProcessor::BoundingBox* head) 
{ 
    BoundingBox* iter;
    RunRegion* v;
    
    std::cout << " --------- BOUNDING BOX --------- \n";
    std::cout << "Color: "<<  head->color << ".\n";
    for (iter = head; iter != NULL; iter = iter->nextBox){
        std::cout << "Box at " << iter << ", Size of box: "<< iter->numPixels << ", Number of enclosed run regions: " << iter->numRunLengths << "\n";
        for (RunRegion* v : iter->listRR){
            std::cout << "\t Run region " <<  v << " at xLoc: " << v->xLoc << " and yLoc: " << v->yLoc <<", Size of run region: " << v->runLength << ", Color: "<<  v->color << "\n";
        }
        std::cout << "Next Box " << iter->nextBox <<"\n";
        std::cout << "Previous Box " << iter->prevBox <<"\n";
    }
    // loop until the down pointer is not NULL     
} 



