#ifndef GOALPOINT_H
#define GOALPOINT_H
struct GoalPoint {
  Point2D loc;
  int type;
};
#endif
